DROP INDEX sp_index ON Location;

DROP TABLE IF EXISTS Location;